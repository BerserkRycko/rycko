---
title: '{{ replace .Name "-" " " | title }}'
---

This is a page about »{{ replace .Name "-" " " | title }}«.
