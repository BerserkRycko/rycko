---
title: '{{ replace .Name "-" " " | title }}'
# The "weight" will determine where this section appears on the "homepage".
# A bigger weight will place the content more towards the bottom of the page.
# It's like gravity ;-).
weight: 5
# If "header_menu" is true, then a button linking to this section will be placed
# into the header menu at the top of the homepage.
header_menu: true
---

This is just another section to appear on the homepage.
