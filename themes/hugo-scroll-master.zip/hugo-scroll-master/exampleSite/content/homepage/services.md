---
title: "Services"
weight: 2
header_menu: true
---

That is the important part, right? You want to know what I can do for you. This is why I put this right up there into the header menu of the website.

---

## Nutrition Coaching

This is not an easy task. You will likely have to pay money for this. You know what - let us look at a nice picture first.

![Nice picture to make you pay me ;-)](images/selective-focus-photography-of-pasta-with-tomato-and-basil-1279330.jpg)

Wow. That was nice, right? Well, call me and let us talk.

---

## Chef Consulting

Did you see the picture above? I can show you how to go from

![Let us get started on a clean slate](images/board-bunch-cooking-food-349609.jpg)

to

![Let us get started on a clean slate](images/woman-pouring-juice-on-glass-3184192.jpg)

in estimated seconds.

---

Want to learn more about my services?

Check out [this page](services) I created. It carries a lot more details...
